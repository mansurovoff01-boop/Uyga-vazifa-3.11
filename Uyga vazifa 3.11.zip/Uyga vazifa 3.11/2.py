import os
os.system("cls")

def student(a):
    natija = []
    for i in a:
        ism = i[0]
        baholar =i[1]

        ortacha = sum(baholar) / len(baholar)
        natija.append([ism, round(ortacha,2)])

    return natija

print(student([['Ali', [5, 4, 3]], ['Gulnoza', [4, 4, 5]]]))

