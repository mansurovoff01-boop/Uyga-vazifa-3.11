import os
os.system("cls")

def filtr(a):
    natija = []

    for i in a:
        if i["narx"] < 10000 and i["tur"] == "ichimlik":
            natija.append(i)

    return natija

mahsulot = [
  {'nom': 'Cola', 'narx': 9000, 'tur': 'ichimlik'},
  {'nom': 'Non', 'narx': 3000, 'tur': 'ovqat'},
  {'nom': 'Suv', 'narx': 5000, 'tur': 'ichimlik'}
]

print(filtr(mahsulot))