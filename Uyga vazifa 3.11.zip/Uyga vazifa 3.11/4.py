import os
os.system("cls")

def matrisa(a):
    natija = []

    for i in a:
        natija.append(i.count(1))
    return natija

print(matrisa([[1, 0, 1], [1, 1, 0], [0, 0, 1]]))