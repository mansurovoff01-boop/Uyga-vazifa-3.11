import os
os.system("cls")

def guruhshlash(studentlar):
    natija = {}

    for ism,baho in studentlar.items():
        if baho not in natija:
            natija[baho] = []

        natija[baho].append(ism)
        
    return natija

studentlar = {'Ali': 5, 'Vali': 4, 'Gulnoza': 5}

print(guruhshlash(studentlar))