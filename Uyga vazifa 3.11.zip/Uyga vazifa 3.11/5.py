import os
os.system("cls")

def telefon(a,b):
    for b in a:
        return a[b]
    return "Topilmadi"

a = {'Ali': '998901234567', 'Gulnoza': '998935678901'}

ism = input("Ism:")

print(telefon(a, ism))        