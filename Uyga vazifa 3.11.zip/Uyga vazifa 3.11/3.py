import os
os.system("cls")

def mahsulotlar(a):
    natija = []

    for i in a:
        nomi = i[0]
        narx = i[1]

        kichigi = min(narx)
        natija.append([nomi, kichigi])
    return natija

print(mahsulotlar([['Olma', [12000, 11000, 11500]], ['Banan', [13000, 12500]]]))