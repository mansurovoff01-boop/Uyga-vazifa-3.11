import os
os.system("cls")

def email_tekshir():
    email = input("Email: ")

    if "@" in email and email[0] != "@":
        a = email.split("@")[1]

        if a == "gmail.com" or a == "mail.com":
            return True

    return False


print(email_tekshir())